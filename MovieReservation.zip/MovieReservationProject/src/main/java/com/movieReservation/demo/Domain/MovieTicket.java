package com.movieReservation.demo.Domain;

import java.time.LocalDateTime;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

/**
 * Movie ticket object.
 * 
 * @author toshiya.kuroki
 */
@JsonSerialize
public class MovieTicket {
	
	/**
	 * チケットの合計金額
	 * Total ticket price.
	 */
	private final int totalPrice;
	
	/**
	 * 購入チケット数
	 * Number of tickets purchased.
	 */
	private final int numberOfTickets;
	
	/**
	 * 予約時間
	 * Reservation time.
	 */
	private final LocalDateTime localDateTime;
	
	/**
	 * 料金タイプの日時
	 * Price type date and time.
	 */
	private final ScreeningTime screeningTime;
	
	/**
	 * 料金タイプ
	 * Price type.
	 */
	private final TicketPriceType ticketPriceType;
	
	/**
	 * チケットの料金
	 * Ticket price.
	 */
	private final TicketPrice ticketPrice;
	
	/**
	 * Creates new instance.
	 * 
	 * @param localDateTime,numberOfTickets
	 */
	public MovieTicket(LocalDateTime localDateTime, int numberOfTickets) {
		this.localDateTime = localDateTime;
		screeningTime = new ScreeningTime(localDateTime);
		ticketPriceType = new TicketPriceType(screeningTime);
		ticketPrice = new TicketPrice(screeningTime);
		this.numberOfTickets = numberOfTickets;
		totalPrice = this.numberOfTickets * ticketPrice.getTicketPrice();
	}
	
	/**
	 * Creates new instance.
	 * 
	 * @param builder
	 */
	public MovieTicket(Builder builder) {
		this.localDateTime = builder.localDateTime;
		this.screeningTime = builder.screeningTime;
		this.ticketPriceType = builder.ticketPriceType;
		this.ticketPrice = builder.ticketPrice;
		this.numberOfTickets = builder.numberOfTickets;
		this.totalPrice = builder.totalPrice;
	}

	/**
	 * Returns totalPrice.
	 * 
	 * @return totalPrice
	 */
	public int getTotalPrice() {
		return totalPrice;
	}
	/**
	 * Returns numberOfTickets.
	 * 
	 * @return numberOfTickets
	 */
	public int getNumberOfTickets() {
		return numberOfTickets;
	}
	/**
	 * Returns localDateTime.
	 * 
	 * @return localDateTime
	 */
	public LocalDateTime getLocalDateTime() {
		return localDateTime;
	}
	/**
	 * Returns screeningTime.
	 * 
	 * @return screeningTime
	 */
	public ScreeningTime getScreeningTime() {
		return screeningTime;
	}
	/**
	 * Returns ticketPriceType.
	 * 
	 * @return ticketPriceType
	 */
	public TicketPriceType getTicketPriceType() {
		return ticketPriceType;
	}
	/**
	 * Returns ticketPrice.
	 * 
	 * @return ticketPrice
	 */
	public TicketPrice getTicketPrice() {
		return ticketPrice;
	}
	
	/**
	 * Builder object
	 */
	public static class Builder {
		
		/**
		 * チケットの合計金額
		 * Total ticket price.
		 */
		private int totalPrice;
		
		/**
		 * 購入チケット数
		 * Number of tickets purchased.
		 */
		private int numberOfTickets;
		
		/**
		 * 予約時間
		 * Reservation time.
		 */
		private LocalDateTime localDateTime;
		
		/**
		 * 料金タイプの日時
		 * Price type date and time.
		 */
		private ScreeningTime screeningTime;
		
		/**
		 * 料金タイプ
		 * Price type.
		 */
		private TicketPriceType ticketPriceType;
		
		/**
		 * チケットの料金
		 * Ticket price.
		 */
		private TicketPrice ticketPrice;

		/**
		 * Sets property.
		 * 
		 * @param totalPrice
		 * @return this instance
		 */
		public Builder totalPrice(final int totalPrice) {
			this.totalPrice = totalPrice;
			return this;
		}
		/**
		 * Sets property.
		 * 
		 * @param numberOfTickets
		 * @return this instance
		 */
		public Builder numberOfTickets(final int numberOfTickets) {
			this.numberOfTickets = numberOfTickets;
			return this;
		}
		/**
		 * Sets property.
		 * 
		 * @param localDateTime
		 * @return this instance
		 */
		public Builder localDateTime(final LocalDateTime localDateTime) {
			this.localDateTime = localDateTime;
			return this;
		}
		/**
		 * Sets property.
		 * 
		 * @param screeningTime
		 * @return this instance
		 */
		public Builder screeningTime(final ScreeningTime screeningTime) {
			this.screeningTime = screeningTime;
			return this;
		}
		/**
		 * Sets property.
		 * 
		 * @param ticketPriceType
		 * @return this instance
		 */
		public Builder ticketPriceType(final TicketPriceType ticketPriceType) {
			this.ticketPriceType = ticketPriceType;
			return this;
		}
		/**
		 * Sets property.
		 * 
		 * @param ticketPrice
		 * @return this instance
		 */
		public Builder ticketPrice(final TicketPrice ticketPrice) {
			this.ticketPrice = ticketPrice;
			return this;
		}
		/**
		 * Builds the result object.
		 * 
		 * @return created object
		 */
		public MovieTicket build() {
			return new MovieTicket(this);
		}
	}
}
