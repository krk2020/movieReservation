package com.movieReservation.demo.Controller;

import java.time.LocalDateTime;
import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import com.movieReservation.demo.Domain.MovieTicket;
import com.movieReservation.demo.Domain.ScreeningTime;
import com.movieReservation.demo.Domain.TicketPrice;
import com.movieReservation.demo.Domain.TicketPriceType;
import com.movieReservation.demo.Domain.MovieReservationList;

/**
 * MovieReservationListのシリアライズを出力する
 * Output MovieTicket class serialization.
 * 
 * @author toshiya.kuroki
 */
@RestController
public class MovieReservationController {

	/**
	 * Get the current date and time.
	 */
	private LocalDateTime localDateTimeNow = LocalDateTime.now();

	/**
	 * Get the specified date and time.
	 */
	private LocalDateTime localDateTime = LocalDateTime.parse("2022-09-02T20:30");

	/**
	 * Get the specified date and time.
	 */
	private LocalDateTime localDateTime2 = LocalDateTime.parse("2022-09-01T19:59");

	/**
	 * Get the specified date and time.
	 */
	private LocalDateTime localDateTime3 = LocalDateTime.parse("2022-09-02T19:59");
	
	/**
	 * create instance.
	 */
	private MovieReservationList movieReservationList = new MovieReservationList();

	/**
	 * book a ticket.
	 */
	MovieTicket movieTicket = new MovieTicket(localDateTimeNow.withNano(0),9);

	/**
	 * book a ticket.
	 */
	MovieTicket movieTicket2 = new MovieTicket(localDateTime,1);

	/**
	 * book a ticket.
	 */
	MovieTicket movieTicket3 = new MovieTicket(localDateTime2,2);

	/**
	 * book a ticket.
	 */
	MovieTicket movieTicket4 = new MovieTicket(localDateTime3,2);
	/**
	 * movieReservationList serialization.
	 * 
	 * @return movieReservationList object
	 */
	@GetMapping("/movieReservation")
	public List<MovieTicket> movieReservation() {
		
		//builder
		movieReservationList.ticketReservation(
		new MovieTicket.Builder().totalPrice(2000).numberOfTickets(2).
		localDateTime(LocalDateTime.parse("2022-09-01T20:00")).
		screeningTime(new ScreeningTime(LocalDateTime.parse("2022-09-01T20:00"))).
		ticketPriceType(new TicketPriceType(new ScreeningTime(LocalDateTime.parse("2022-09-01T20:00")))).
		ticketPrice(new TicketPrice(new ScreeningTime(LocalDateTime.parse("2022-09-01T20:00")))).build());
	
		movieReservationList.ticketReservation(movieTicket);
		movieReservationList.ticketReservation(movieTicket2);
		movieReservationList.ticketReservation(movieTicket3);
		movieReservationList.ticketReservation(movieTicket4);
		return movieReservationList.getMovieTicketList();
	}
}