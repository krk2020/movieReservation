package com.movieReservation.demo.Domain;

import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

/**
 * MovieTicketをリストに追加し所持する
 * Add Movie Ticket to the list and have it.
 * 
 * @author toshiya.kuroki
 */
@JsonSerialize
public class MovieReservationList {
	
	/**
	 * Object to add movieTicket.
	 */
	private List<MovieTicket> movieTicketList;

	/**
	 * 予約済み日時以外のMovieTicketをmovieTicketListに追加する
	 * Add MovieTickets other than the reserved date and time to the list.
	 * 
	 * @param movieTicket
	 */
	public void ticketReservation(MovieTicket movieTicket) {
		//初回
		if(movieTicketList == null) {
			movieTicketList = new ArrayList<MovieTicket>();
			movieTicketList.add(movieTicket);
			return;
		}
		//2回目以降
		for (MovieTicket ticket : movieTicketList) {
			if(ticket.getLocalDateTime().isEqual(movieTicket.getLocalDateTime())) {
				return;
			}
		}
		movieTicketList.add(movieTicket);
	}

	/**
	 * movieTicketListを取得する
	 * get movieTicketList.
	 * 
	 * @return movieTicketList
	 */
	public List<MovieTicket> getMovieTicketList() {
		return this.movieTicketList;
	}
}
