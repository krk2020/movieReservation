package com.movieReservation.demo;

import java.time.LocalDateTime;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.movieReservation.demo.Domain.MovieReservationList;
import com.movieReservation.demo.Domain.MovieTicket;

/**
 * Movie ticket reservation object.
 * 
 * @author toshiya.kuroki
 */
@JsonSerialize
@SpringBootApplication
public class MoviePriceProjectApplication {

	/**
	 * main method.
	 */
	public static void main(String[] args) {
		
		/**
		 * Springアプリケーションをブートストラップする
		 * Bootstrap a Spring application.
		 */
		SpringApplication.run(MoviePriceProjectApplication.class, args);
		
		/**
		 * MovieReservationListのインスタンスを作成する
		 * Create an instance of MovieReservationList.
		 */
		MovieReservationList movieReservationList = new MovieReservationList();
		
		/**
		 * ticket purchase.
		 * 
		 * @param LocalDateTime,number of tickets.
		 */
		MovieTicket order = new MovieTicket(LocalDateTime.parse("2020-09-01T12:30"), 2);
		
		/**
		 * Add to movieReservationList.
		 * 
		 * @param order.
		 */
		movieReservationList.ticketReservation(order);
		
	}

}
