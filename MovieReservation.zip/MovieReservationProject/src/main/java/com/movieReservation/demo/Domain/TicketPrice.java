package com.movieReservation.demo.Domain;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

/**
 * 映画のチケット料金を返す
 * return movie ticket prices.
 * 
 * @author toshiya.kuroki
 */
@JsonSerialize
public class TicketPrice {
	
	/**
	 * price of the movie.
	 */
	private final int ticketPrice;
	
	/**
	 * ScreeningTimeに応じた金額を設定する
	 * Set the amount according to ScreeningTime.
	 * 
	 * @param screeningTime
	 */
	public TicketPrice(ScreeningTime screeningTime) {
		if (screeningTime.isLateShow()) {
			ticketPrice = 1000;
			return;
		}
		if (screeningTime.isCinemaDay()) {
			ticketPrice = 1500;
			return;
		}
		ticketPrice = 1800;
		return;
	}

	/**
	 * ticketPriceを返す
	 * return ticketPrice.
	 * 
	 * @return ticketPrice
	 */
	public int getTicketPrice() {
		return ticketPrice;
	}
}
