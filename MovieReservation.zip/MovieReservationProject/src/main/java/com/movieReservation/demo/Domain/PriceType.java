package com.movieReservation.demo.Domain;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

/**
 * チケットタイプを列挙型で設定する
 * Set ticket type as enum.
 * 
 * @author toshiya.kuroki
 */
@JsonSerialize
public enum PriceType {

	/**
	 * 通常料金
	 * basic ticket.
	 */
	BASIC, 
	/**
	 * 映画の日
	 * cinema day.
	 */
	CINEMA_DAY, 
	/**
	 * 夜間上映
	 * late show.
	 */
	LATE_SHOW;
	
}
