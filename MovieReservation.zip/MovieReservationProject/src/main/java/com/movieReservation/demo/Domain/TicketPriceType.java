package com.movieReservation.demo.Domain;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

/**
 * チケットタイプを設定する
 * Set ticket type.
 * 
 * @author toshiya.kuroki
 */
@JsonSerialize
public class TicketPriceType {

	/**
	 * チケットタイプ
	 * ticket price type.
	 */
	private final PriceType ticketType;

	/**
	 * ScreeningTimeに応じたチケットタイプを設定する
	 * Set ticket type according to ScreeningTime.
	 * 
	 * @param screeningTime
	 */
	public TicketPriceType(ScreeningTime screeningTime) {
		if (screeningTime.isLateShow()) {
			ticketType = PriceType.LATE_SHOW;
			return;
		}
		if (screeningTime.isCinemaDay()) {
			ticketType = PriceType.CINEMA_DAY;
			return;
		}
		ticketType = PriceType.BASIC;
		return;
	}

	/**
	 * チケットタイプを返す
	 * Returns the ticket type.
	 * 
	 * @return ticketType
	 */
	public PriceType getTicketPriceType() {
		return ticketType;
	}
}


