package com.movieReservation.demo.Domain;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.TemporalAccessor;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

/**
 * 映画の予約日時を返す
 * return movie reservation date and time.
 * 
 * @author toshiya.kuroki
 */
@JsonSerialize
public class ScreeningTime {

	/**
	 * Movie reservation date.
	 */
	private final LocalDate date;
	
	/**
	 * Movie reservation time.
	 */
	private final LocalTime time;
	
	/**
	 * Movie reservation date and time.
	 */
	private final LocalDateTime localDateTime;
	
	/**
	 * Creates new instance.
	 * 
	 * @param localDateTime
	 */
	public ScreeningTime(LocalDateTime localDateTime){
		this.localDateTime = localDateTime;
		TemporalAccessor temporalAccessor = localDateTime;
		date = LocalDate.from(temporalAccessor);
		time = localDateTime.toLocalTime();
	}

	/**
	 * Determine if it is a CinemaDay.
	 * 
	 * @return date.getDayOfMonth()
	 */
	public boolean isCinemaDay() {
		return date.getDayOfMonth() == 1;
	}

	/**
	 * Determine if it is a Late Show.
	 * 
	 * @return time.getHour()
	 */
	public boolean isLateShow() {
		return 20 <= time.getHour();
	}
}
