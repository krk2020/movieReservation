package com.movieReservation.demo;

import static org.junit.Assert.assertEquals;
import java.time.LocalDateTime;
import org.junit.jupiter.api.Test;
import com.movieReservation.demo.Domain.ScreeningTime;
import com.movieReservation.demo.Domain.TicketPrice;

/**
 * Test that proves that class for TicketPrice is working.
 * 
 * @author toshiya.kuroki
 */
public class TicketPriceTest {
	
	/**
	 * Creates new instance.
	 */
	public TicketPriceTest() {
	}
	
	/**
	 * Tests if the value of ticketPrice is correct.
	 */
	@Test
	public void testTicketPrice() {
		//first test
		ScreeningTime screeningTime = new ScreeningTime(LocalDateTime.parse("2022-09-01T20:00"));
		TicketPrice ticketPrice = new TicketPrice(screeningTime);
		assertEquals(ticketPrice.getTicketPrice(), 1000);
		
		//second test
		screeningTime = new ScreeningTime(LocalDateTime.parse("2022-09-01T19:59"));
		ticketPrice = new TicketPrice(screeningTime);
		assertEquals(ticketPrice.getTicketPrice(), 1500);
		
		//third test
		screeningTime = new ScreeningTime(LocalDateTime.parse("2022-09-02T19:59"));
		ticketPrice = new TicketPrice(screeningTime);
		assertEquals(ticketPrice.getTicketPrice(), 1800);
	}
}
