package com.movieReservation.demo;

import static org.junit.Assert.assertEquals;
import java.time.LocalDateTime;
import org.junit.jupiter.api.Test;
import com.movieReservation.demo.Domain.MovieTicket;
import com.movieReservation.demo.Domain.ScreeningTime;
import com.movieReservation.demo.Domain.TicketPrice;
import com.movieReservation.demo.Domain.TicketPriceType;

/**
 * Test that proves that class for MovieTicket is working.
 * 
 * @author toshiya.kuroki
 */
public class MovieTicketTest {

	/**
	 * Creates new instance.
	 */
	public MovieTicketTest() {
	}
	
	/**
	 * Tests if the value of movieTicket is correct.
	 */
	@Test
	public void testMovieTicket() {

		ScreeningTime screeningTime = new ScreeningTime(LocalDateTime.parse("2022-09-01T20:00"));
		TicketPrice ticketPrice = new TicketPrice(screeningTime);
		TicketPriceType ticketPriceType = new TicketPriceType(screeningTime);
		
		MovieTicket movieTicket = new MovieTicket.Builder().totalPrice(3000).numberOfTickets(3).
		localDateTime(LocalDateTime.parse("2022-09-01T20:00")).screeningTime(screeningTime).
		ticketPriceType(ticketPriceType).ticketPrice(ticketPrice).build();
		
		//first test
		assertEquals(movieTicket.getTotalPrice(), 3000);
		assertEquals(movieTicket.getNumberOfTickets(), 3);
		assertEquals(movieTicket.getLocalDateTime(), LocalDateTime.parse("2022-09-01T20:00"));
		assertEquals(movieTicket.getTicketPrice(), ticketPrice);
		assertEquals(movieTicket.getScreeningTime(), screeningTime);
		assertEquals(movieTicket.getTicketPriceType(), ticketPriceType);
	}
	
}
