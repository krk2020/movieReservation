package com.movieReservation.demo;

import static org.junit.Assert.assertEquals;
import java.time.LocalDateTime;
import org.junit.jupiter.api.Test;
import com.movieReservation.demo.Domain.MovieReservationList;
import com.movieReservation.demo.Domain.MovieTicket;
import com.movieReservation.demo.Domain.ScreeningTime;
import com.movieReservation.demo.Domain.TicketPrice;
import com.movieReservation.demo.Domain.TicketPriceType;

/**
 * Test that proves that class for movieReservationListTest is working.
 * 
 * @author toshiya.kuroki
 */
public class MovieReservationListTest {

	/**
	 * Creates new instance.
	 */
	public MovieReservationListTest() {
	}
	
	/**
	 * Tests if the value of movieReservationListTest is correct.
	 */
	@Test
	public void testMovieReservationList() {

		//first test
		MovieReservationList movieReservationList = new MovieReservationList();
		movieReservationList.ticketReservation(
		new MovieTicket.Builder().totalPrice(2000).numberOfTickets(2).
		localDateTime(LocalDateTime.parse("2022-09-01T20:00")).
		screeningTime(new ScreeningTime(LocalDateTime.parse("2022-09-01T20:00"))).
		ticketPriceType(new TicketPriceType(new ScreeningTime(LocalDateTime.parse("2022-09-01T20:00")))).
		ticketPrice(new TicketPrice(new ScreeningTime(LocalDateTime.parse("2022-09-01T20:00")))).build());
	
		assertEquals(movieReservationList.getMovieTicketList().size(),1);
		
		//second test
		movieReservationList.ticketReservation(
		new MovieTicket.Builder().totalPrice(1800).numberOfTickets(1).
		localDateTime(LocalDateTime.parse("2022-09-01T19:59")).
		screeningTime(new ScreeningTime(LocalDateTime.parse("2022-09-01T19:59"))).
		ticketPriceType(new TicketPriceType(new ScreeningTime(LocalDateTime.parse("2022-09-01T19:59")))).
		ticketPrice(new TicketPrice(new ScreeningTime(LocalDateTime.parse("2022-09-01T19:59")))).build());
	
		assertEquals(movieReservationList.getMovieTicketList().size(),2);
		
		//third test
		movieReservationList.ticketReservation(
		new MovieTicket.Builder().totalPrice(2000).numberOfTickets(2).
		localDateTime(LocalDateTime.parse("2022-09-01T20:00")).
		screeningTime(new ScreeningTime(LocalDateTime.parse("2022-09-01T20:00"))).
		ticketPriceType(new TicketPriceType(new ScreeningTime(LocalDateTime.parse("2022-09-01T20:00")))).
		ticketPrice(new TicketPrice(new ScreeningTime(LocalDateTime.parse("2022-09-01T20:00")))).build());
	
		assertEquals(movieReservationList.getMovieTicketList().size(),2);
		
	}

}
