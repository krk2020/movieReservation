package com.movieReservation.demo;

import static org.junit.Assert.assertEquals;
import java.time.LocalDateTime;
import org.junit.jupiter.api.Test;
import com.movieReservation.demo.Domain.PriceType;
import com.movieReservation.demo.Domain.ScreeningTime;
import com.movieReservation.demo.Domain.TicketPriceType;

/**
 * Test that proves that class for TicketPriceType is working.
 * 
 * @author toshiya.kuroki
 */
public class TicketPriceTypeTest {

	/**
	 * Creates new instance.
	 */
	public TicketPriceTypeTest() {
	}

	/**
	 * Tests if the value of ticketType is correct.
	 */
	@Test
	public void testTicketPrice() {
		//first test
		ScreeningTime screeningTime = new ScreeningTime(LocalDateTime.parse("2022-09-01T20:00"));
		TicketPriceType ticketPriceType = new TicketPriceType(screeningTime);
		assertEquals(ticketPriceType.getTicketPriceType(), PriceType.LATE_SHOW);
		
		//second test
		screeningTime = new ScreeningTime(LocalDateTime.parse("2022-09-01T19:59"));
		ticketPriceType = new TicketPriceType(screeningTime);
		assertEquals(ticketPriceType.getTicketPriceType(), PriceType.CINEMA_DAY);
		
		//third test
		screeningTime = new ScreeningTime(LocalDateTime.parse("2022-09-02T19:59"));
		ticketPriceType = new TicketPriceType(screeningTime);
		assertEquals(ticketPriceType.getTicketPriceType(), PriceType.BASIC);
	}
	
	
	
	
}
